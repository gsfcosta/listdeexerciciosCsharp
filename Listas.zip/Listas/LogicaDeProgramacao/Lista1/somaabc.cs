﻿namespace LogicaDeProgramacao.Lista1
{
    internal class somaabc
    {
    }
}