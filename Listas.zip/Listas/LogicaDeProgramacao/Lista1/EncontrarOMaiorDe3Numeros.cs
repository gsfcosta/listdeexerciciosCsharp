﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaDeProgramacao.Lista1
{
    public class EncontrarOMaiorDe3Numeros : IExercicio
    {
        /*
            Deve encontrar o maior dos 3 números  (a, b, c)
        */

        public bool VerificarResposta()
        {
            return
                   Validar.SaoIguais(3, () => Rodar(3, 2, 1))
                && Validar.SaoIguais(3, () => Rodar(1, 2, 3))
                && Validar.SaoIguais(3, () => Rodar(1, 3, 2))
                ;
        }

        public int Rodar(int a, int b, int c)
        {
            int maior;
            if (a > b && b > c)
            {
                maior = a;
            }
            else if (a > b && b < c)
            {
                if (a > c)
                {
                    maior = a;
                }
                else
                {
                    maior = c;
                }
            }
            else if (b > c)
            {
                maior = b;
            }
            else
            {
                maior = c;
            }
            return maior;
        }
    }
}
