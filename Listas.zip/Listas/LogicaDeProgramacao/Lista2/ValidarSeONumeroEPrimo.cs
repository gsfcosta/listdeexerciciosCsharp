using System;

namespace LogicaDeProgramacao.Lista2
{

    public class ValidarSeONumeroEPrimo : IExercicio
    {
        public bool VerificarResposta()
        {
            return
                  Validar.SaoIguais(true, () => Rodar(1))
               && Validar.SaoIguais(false, () => Rodar(4))
               && Validar.SaoIguais(true, () => Rodar(7))
               && Validar.SaoIguais(false, () => Rodar(900000000))
               && Validar.SaoIguais(true, () => Rodar(999983));
        }

        public bool Rodar(int n)
        {
            int num = 2;
            bool resultado = false;
            if (n != 1)
            {
                while (n > num)
                {
                    float resto = n % num;
                    if (resto == 0)
                    {
                        resultado = false;
                        num = n + 1;
                    }
                    else
                    {
                        num++;
                        if (n == num)
                        {
                            resultado = true;
                        }
                    }

                }
            }
            else
            {
                resultado = true;
            }
            return resultado;
        }
    }
}