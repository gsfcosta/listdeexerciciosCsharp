﻿using System;

namespace LogicaDeProgramacao.Lista2
{
    public class CaixaEletronico : IExercicio
    {
        /*
            Um caixa eletrônico entrega notas de 2, 5, 10, 20, 50 e 100 (as notas do Real)
            Ele deve entregar sempre as maiores notas, entergando notas menores apenas quando necessário.
            Exemplo: Para um saque de 30, deve entregar uma de 20 e outra de 10. Não se pode entregar 3 de 10.

            A representação da entrega deve ser feita na forma de um int[6]. 
            O valor do indice 1 é a quantidade de notas de 2
            O valor do indice 2 é a quantidade de notas de 5
            E assism vai até o indice 5 que é a quantidade de notas de 100.
        */

        public bool VerificarResposta()
        {
            return
                /* corrigir notas para que seja retirado o total do solicitado */
                   Validar.SaoIguais(new[] { 00, 00, 00, 02, 00, 00 }, () => Rodar(40))
                && Validar.SaoIguais(new[] { 03, 00, 00, 01, 01, 00 }, () => Rodar(76)) /* { 03, 00, 00, 01, 01, 00 } */
                && Validar.SaoIguais(new[] { 03, 01, 00, 02, 01, 09 }, () => Rodar(1001)) /* { 03, 01, 00, 02, 01, 09 } */
                ;
        }

        public int[] Rodar(int valor)
        {
            int[] notas = new int[6];
            notas[0] = 0;
            notas[1] = 0;
            notas[2] = 0;
            notas[3] = 0;
            notas[4] = 0;
            notas[5] = 0;

            while (valor != 0)
            {
                if (valor >= 100)
                {
                    valor = valor - 100;
                    notas[5]++;
                }
                else if (valor >= 50)
                {
                    valor = valor - 50;
                    notas[4]++;
                }
                else if (valor >= 20)
                {
                    valor = valor - 20;
                    notas[3]++;
                }
                else if (valor >= 10)
                {
                    if (valor == 13)
                    {
                        valor = valor - 5;
                        notas[1]++;
                    }
                    else if (valor == 11)
                    {
                        valor = valor - 5;
                        notas[1]++;
                    }
                    else
                    {
                        valor = valor - 10;
                        notas[2]++;
                    }
                }
                else if (valor >= 5)
                {
                    if (valor == 9)
                    {
                        valor = valor - 4;
                        notas[0] = notas[0] + 2;
                    }
                    else if (valor == 7)
                    {
                        valor = valor - 2;
                        notas[0]++;
                    }
                    else if (valor == 5)
                    {
                        valor = valor - 5;
                        notas[1]++;
                    }
                    else if (valor == 8)
                    {
                        valor = valor - 8;
                        notas[0] = notas[0] + 4;
                    }
                    else
                    {
                        valor = valor - 6;
                        notas[0] = notas[0] + 3;
                    }
                }
                else if (valor >= 2)
                {
                    if (valor == 4)
                    {
                        valor = valor - 4;
                        notas[0] = notas[0] + 2;
                    }
                    else
                    {
                        valor = valor - 2;
                        notas[0]++;
                    }
                }
            }
            return notas;
        }
    }
}
