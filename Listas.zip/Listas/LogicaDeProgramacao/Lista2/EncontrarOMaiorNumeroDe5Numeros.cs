﻿using System;

namespace LogicaDeProgramacao.Lista2
{
    public class EncontrarOMaiorNumeroDe5Numeros : IExercicio
    {
        /*
            Deve encontrar o maior dos 5 números  (a, b, c, d, e)
        */

        public bool VerificarResposta()
        {
            return
                   Validar.SaoIguais(10, () => Rodar(1, 3, 2, 10, -10))
                && Validar.SaoIguais(5, () => Rodar(4, 3, 2, 2, 5))
                && Validar.SaoIguais(-100, () => Rodar(-100, -200, -100, -101, -200))
                ;
        }

        public int Rodar(int a, int b, int c, int d, int e)
        {
            int maior = 0;
            if (a > 0 || b > 0 || c > 0 || d > 0 || e > 0)
            {
                if (a > b)
                {
                    if (a > c)
                    {
                        if (a > d)
                        {
                            if (a > e)
                            {
                                maior = a;
                            }
                            else
                            {
                                maior = e;
                            }
                        }
                        else if (d > e)
                        {
                            maior = d;
                        }
                        else
                        {
                            maior = e;
                        }
                    }
                    else if (c > d)
                    {
                        if (c > e)
                        {
                            maior = c;
                        }
                        else
                        {
                            maior = e;
                        }
                    }
                    else if (d > e)
                    {
                        maior = d;
                    }
                    else
                    {
                        maior = e;
                    }
                }
                else if (b > c)
                {
                    if (b > d)
                    {
                        if (b > e)
                        {
                            maior = b;
                        }
                        else
                        {
                            maior = e;
                        }
                    }
                    else if (d > c)
                    {
                        if (d > e)
                        {
                            maior = d;
                        }
                        else
                        {
                            maior = e;
                        }
                    }
                    else if (c > e)
                    {
                        maior = c;
                    }
                    else
                    {
                        maior = e;
                    }
                }
                else if (c > d)
                {
                    if (c > e)
                    {
                        maior = c;
                    }
                    else
                    {
                        maior = e;
                    }
                }
                else if (d > e)
                {
                    maior = d;
                }
                else
                {
                    maior = e;
                }
            }
            if (a < b)
            {
                if (a < c)
                {
                    if (a < d)
                    {
                        if (a < e)
                        {
                            maior = a;
                        }
                        else
                        {
                            maior = e;
                        }
                    }
                    else if (d < e)
                    {
                        maior = d;
                    }
                    else
                    {
                        maior = e;
                    }
                }
                else if (c < d)
                {
                    if (c < e)
                    {
                        maior = c;
                    }
                    else
                    {
                        maior = e;
                    }
                }
                else if (d < e)
                {
                    maior = d;
                }
                else
                {
                    maior = e;
                }
            }
            else if (b < c)
            {
                if (b < d)
                {
                    if (b < e)
                    {
                        maior = b;
                    }
                    else
                    {
                        maior = e;
                    }
                }
                else if (d < c)
                {
                    if (d < e)
                    {
                        maior = d;
                    }
                    else
                    {
                        maior = e;
                    }
                }
                else if (c < e)
                {
                    maior = c;
                }
                else
                {
                    maior = e;
                }
            }
            else if (c < d)
            {
                if (c < e)
                {
                    maior = c;
                }
                else
                {
                    maior = e;
                }
            }
            else if (d < e)
            {
                maior = d;
            }
            else
            {
                maior = e;
            }
            return maior;
        }
    }
}
