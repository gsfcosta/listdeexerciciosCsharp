﻿using System;

namespace LogicaDeProgramacao.Lista2
{
    public class CalculadoraDeMediaSimples : IExercicio
    {
        public bool VerificarResposta()
        {
            return
                  Validar.SaoIguais(2, () => Rodar(2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2))
               && Validar.SaoIguais(6, () => Rodar(10, 3, 0, -1))
               ;
        }

        public int Rodar(params int[] numeros)
        {
            int indice = 0;
            int valor = numeros[indice];
            indice++;
            while (numeros.Length >= indice)
            {
                valor = valor + numeros[indice];
                indice++;
            }
            int media = valor / indice;
            return media;        
        }
    }
}
